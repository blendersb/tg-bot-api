import re
import time
import math
import logging
import secrets
import mimetypes
from aiohttp import web
import sys

from Onestreamer.tgbot import tg

from Onestreamer import bot_info,StartTime, __version__

routes = web.RouteTableDef()


#Creating GeneralPage ,HomePage
@routes.get("/")
async def handle_get_request1(req: web.Request) -> web.Response:
    return web.Response(text="Welcome To @MFBlendersBot",
                        content_type="application/json")


#async def handle_request1(req: web.Request,
                          #head: bool = False) -> web.Response:
    


#########################################################
