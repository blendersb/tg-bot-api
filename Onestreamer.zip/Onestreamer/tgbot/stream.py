import re
import json
import re

class MessageFilter:

    @staticmethod
    def is_command(update):
        message = update.get('message', {})
        text = message.get('content', {}).get('text', {})

        if message.get('content', {}).get('@type') == 'messageText':
            entities = message.get('content', {}).get('text', {}).get('entities', [])
            return entities and entities[0].get('type').get('@type') == 'textEntityTypeBotCommand'

        return False
    @staticmethod
    def is_start(update):
        message = update.get('message', {})
        text = message.get('content', {}).get('text', {})

        if message.get('content', {}).get('@type') == 'messageText':
            entities = message.get('content', {}).get('text', {}).get('entities', [])
            return text.get('text','')=='/start' and entities[0].get('type').get('@type') == 'textEntityTypeBotCommand'

        return False

    @staticmethod
    def is_forwarded(update):
        message = update.get('message', {})
        return message.get('forward_info')

    @staticmethod
    def is_audio(update):
        message = update.get('message', {})
        return message.get('content', {}).get('@type') == 'messageAudio'

    @staticmethod
    def is_video(update):
        message = update.get('message', {})
        return message.get('content', {}).get('@type') == 'messageVideo'

    @staticmethod
    def is_document(update):
        message = update.get('message', {})
        return message.get('content', {}).get('@type') == 'messageDocument'

    @staticmethod
    def is_animation(update):
        message = update.get('message', {})
        return message.get('content', {}).get('@type') == 'messageAnimation'

    @staticmethod
    def is_reply(update):
        message = update.get('message', {})
        return message.get('reply_to_message_id')

    @staticmethod
    def is_inline_query(update):
        message = update.get('message', {})
        text = message.get('content', {}).get('text', '')

        return message.get('content', {}).get('@type') == 'messageText' and text.get('@type') == 'formattedText'

    @staticmethod
    def has_url(text):
        return re.search(r'https?://', text)

    @staticmethod
    def has_specific_text(text, specific_text):
        return specific_text.lower() in text.lower()

    @staticmethod
    def filter_and(update, *filters):
        for filter in filters:
            if not filter(update):
                return False
        return True

    @staticmethod
    def filter_or(update, *filters):
        for filter in filters:
            if filter(update):
                return True
        return False
