#from Onestreamer.config import (api_id, api_hash, bot_token)
from telegram.client import Telegram
#from telegram.text import Spoiler
import argparse
#import pkg_resources
import time
from .stream import MessageFilter
#library_path=pkg_resources.resource_filename('telegram', f'lib/linux/libtdjson.so')
library_path='D:/Importent_Proj/py/Onestreamer/tdjson.dll'
tg = Telegram(
        api_id='3786654',
        api_hash='eb413667a83ecfb0c09d02a29215498d',
        bot_token='1857136393:AAFRXz8OGqIH-ga-qb0rM22pwYeVNPmkS00',  # you can pass 'bot_token' instead
        database_encryption_key='Blenderskey97',
        library_path=library_path,
        login=True
    )
print('------------------- Initalizing Telegram Bot -------------------')
'''tg.login()
bot_info = tg.get_me()
__version__ = 1.06
StartTime = time.time()'''