import os
import sys
import time
module_pwd=os.getcwd()
sys.path.append(module_pwd)
from Onestreamer import tg, bot_info
from Onestreamer.server import web_server
from Onestreamer.tgbot import MessageFilter
import asyncio
import logging
from aiohttp import web
#from Onstreamer import Update
#from pathlib import Path
from telegram.utils import parse
loop = asyncio.get_event_loop()
def handle_message(update):
    print(update)
    if MessageFilter.is_start(update):
        print("Received command: This is a command! /start")
        tg.send_message(chat_id=update.get('message', {}).get('sender_id',{}).get('user_id',''),text=f'Welcome To @MFBlendersBot')

    elif MessageFilter.is_command(update):
        print("Received command")

    elif MessageFilter.filter_and(update, MessageFilter.is_video):
        print("Received video message ")
async def start_services():
        
    print('----------------------------- DONE -----------------------------')
    print('\n')
    app = web.AppRunner(await web_server())
    await app.setup()
    bind_address = "0.0.0.0"
    await web.TCPSite(app, bind_address, '8082').start()
    print('----------------------------- DONE -----------------------------')
    print('\n')
    print('----------------------- Service Started -----------------------')
    print('                        bot =>> {}'.format(bot_info))
    
    print('                        server ip =>> {}'.format(
    bind_address, '8082'))
    tg.add_message_handler(handle_message)
    tg.idle()


if __name__ == '__main__':
    try:
        loop.run_until_complete(start_services())
    except KeyboardInterrupt:
        logging.info(
            '----------------------- Service Stopped -----------------------')
